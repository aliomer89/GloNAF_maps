## Ithaca Hot Spots

Here's my sample map website!

<iframe src="Ithaca-map.html" height="500" width="500"></iframe>

You can explore this map [as its own web page here](Ithaca-map.html).

