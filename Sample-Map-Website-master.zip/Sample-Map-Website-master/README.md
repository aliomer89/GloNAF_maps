# Sample Map Website

This repository contains code and files for publishing a Folium map as a very simple GitHub Pages site.

You can check out the website here: https://melaniewalsh.github.io/Sample-Map-Website/

![](sample-map-website-diagram.png)
